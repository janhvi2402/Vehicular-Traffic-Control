"""
ppo/train.py
============
Trains the shared per-junction PPO actor-critic on TrafficGridEnv.
Implements Algorithm 1 ("PPO, Actor-Critic Style") and the combined
clipped-surrogate + value-loss + entropy-bonus objective (Eq. 9) from
Schulman et al., 2017. See ppo/config.py for the full justification of
every hyperparameter against the paper's tables.

Adapted as follows from the paper's setting:
  - n_agents (16 on the 4x4 grid, 9 on the 3x3 generalization network)
    junctions play the role of the paper's N parallel actors, each
    contributing its own length-`horizon` trajectory every update
  - MLP (tanh activations, matching the paper's continuous-control MLP
    architecture) on an 11-dim hand-engineered feature vector, rather than
    the CNN used for Atari's raw pixels
  - like dqn/train.py, supports chunked/resumable runs (--chunk_steps) so
    a long training run can be split across multiple sessions without
    losing progress; only network weights persist across chunks (the
    optimizer's Adam moment estimates reset each chunk, the same
    simplification dqn/train.py makes for its optimizer)

Usage:
    python -m ppo.train --updates 500 --out runs/ppo_run_matched500

    Or just hit Play/F5 with zero arguments -- every default below
    already matches this (500 updates, runs/ppo_run_matched500).
    For a multi-seed run (recommended -- see config.py's disclosed
    limitations on single-seed comparisons), override --seed and --out
    per run, e.g.:
        python -m ppo.train --seed 1 --out runs/ppo_run_matched500_seed1
        python -m ppo.train --seed 2 --out runs/ppo_run_matched500_seed2
"""

from __future__ import annotations

import argparse
import csv
import os
import sys

import numpy as np
import torch
import torch.nn as nn

# Project root = the folder that CONTAINS this "ppo" package. Building
# every default path from this (instead of leaving them as bare relative
# strings) means the script runs the same way from the VS Code Play
# button, "python ppo/train.py", or "python -m ppo.train" -- no terminal
# or command-line arguments required, regardless of what directory VS
# Code happens to set as the current working directory. Mirrors the
# pattern already used throughout dqn/*.py.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

sys.path.insert(0, PROJECT_ROOT)

from environment.grid_env import TrafficGridEnv, GridEnvConfig  # noqa: E402
from ppo.config import PPOConfig  # noqa: E402
from environment.eligibility import eligibility_from_features  # noqa: E402
from environment.seeds import training_env_seed  # noqa: E402
from ppo.actor_critic import ActorCritic, RolloutBuffer, mask_switch_logits  # noqa: E402

DEFAULT_NET_FILE = os.path.join(PROJECT_ROOT, "sumo_4x4_network", "grid4x4.net.xml")
DEFAULT_ROUTE_FILE = os.path.join(PROJECT_ROOT, "sumo_4x4_network", "routes.rou.xml")
DEFAULT_OUT = os.path.join(PROJECT_ROOT, "runs", "ppo_run_matched500")


def train(cfg: PPOConfig, net_file: str, route_file: str, out_dir: str, use_gui: bool = False,
          resume_from: str | None = None, start_update: int = 0, start_episode: int = 0,
          chunk_updates: int | None = None):
    os.makedirs(out_dir, exist_ok=True)
    if chunk_updates is None:
        chunk_updates = cfg.total_updates - start_update

    device = "cuda" if torch.cuda.is_available() else "cpu"
    torch.manual_seed(cfg.seed)

    env_cfg = GridEnvConfig(
        net_file=net_file, route_file=route_file,
        episode_seconds=cfg.episode_seconds, decision_interval=cfg.decision_interval,
        seed=cfg.seed, use_gui=use_gui,
    )
    env = TrafficGridEnv(env_cfg)
    n_agents = env.n_agents

    net = ActorCritic(cfg.input_dim, cfg.hidden_sizes, cfg.n_actions).to(device)
    if resume_from:
        net.load_state_dict(torch.load(resume_from, map_location=device))
        print(f"Resumed weights from {resume_from}")
    optimizer = torch.optim.Adam(net.parameters(), lr=cfg.learning_rate)

    buffer = RolloutBuffer(cfg.horizon, n_agents, cfg.input_dim)
    # seeded minibatch-shuffling RNG (np.random.permutation ignored cfg.seed); offset by start_update so
    # resumed chunks do not replay the first chunk's shuffles
    shuffle_rng = np.random.default_rng(cfg.seed + start_update)

    log_path = os.path.join(out_dir, "train_log.csv")
    write_header = not (resume_from and os.path.exists(log_path))
    # resuming a log written before the *_ep columns existed: keep its column count so rows stay aligned
    log_n_cols = None
    if not write_header:
        with open(log_path) as _f:
            log_n_cols = len(_f.readline().strip().split(","))
    log_file = open(log_path, "a" if resume_from else "w", newline="")
    log_writer = csv.writer(log_file)
    if write_header:
        log_writer.writerow(
            ["update", "env_step", "episode", "episode_reward", "total_waiting_time",
             "throughput", "policy_loss", "value_loss", "entropy",
             # episode aggregates of the last COMPLETED episode (the earlier columns are end-of-episode snapshots)
             "mean_waiting_time_ep", "mean_vehicle_wait_ep"]
        )

    obs, _ = env.reset(seed=training_env_seed(cfg.seed, start_episode))
    episode = start_episode
    episode_reward = 0.0
    ep_wait_sum, ep_steps = 0.0, 0
    last_completed_mean_wait = last_completed_mean_vehicle_wait = float("nan")
    # Captures the just-completed episode's TOTAL reward, for logging
    # after the horizon loop below -- NOT the live `episode_reward`,
    # which is reset to 0.0 the instant an episode ends (see the
    # `if episode_done:` block inside the loop). Since horizon=720
    # exactly equals one episode's length, an episode boundary lands on
    # essentially every update's LAST step -- so by the time the
    # log_writer.writerow() call below runs (after the loop exits),
    # `episode_reward` has almost always already been reset to 0.0 for
    # the NEXT (barely-started) episode. Every logged "episode_reward"
    # would read ~0.0 regardless of how training was actually going.
    # This variable is what the log line uses instead.
    last_completed_episode_reward = 0.0
    env_step = start_update * cfg.horizon

    end_update = min(start_update + chunk_updates, cfg.total_updates)
    for update in range(start_update + 1, end_update + 1):
        buffer.reset()
        for _ in range(cfg.horizon):
            feats = obs["node_features"]
            x = torch.as_tensor(feats, dtype=torch.float32, device=device)
            eligible_np = eligibility_from_features(feats, env.cfg.min_green, env.cfg.max_green)
            actions, log_probs, values = net.act(x, torch.as_tensor(eligible_np, device=device))
            actions_np = actions.cpu().numpy()  # executed actions: ineligible rows are always 0

            next_obs, reward, terminated, truncated, info = env.step(actions_np)
            assert np.array_equal(actions_np, info["executed_actions"]), "executed action mismatch"
            episode_done = terminated or truncated
            episode_reward += reward
            env_step += 1
            ep_wait_sum += info["total_waiting_time"]; ep_steps += 1

            agent_rewards = np.clip(info["agent_rewards"], -cfg.reward_clip, cfg.reward_clip)

            if truncated and not terminated:
                # This env only ever ends via the 3600s time limit --
                # terminated is always False, there is no true absorbing
                # state. compute_gae() zeroes the bootstrap wherever
                # buffer.dones[t]==1 (correctly, since self.values[t+1]
                # would otherwise belong to the NEXT, freshly-reset
                # episode -- an unrelated trajectory it must not bootstrap
                # from). But that means a plain truncation would silently
                # tell GAE this state's continuation is worth exactly 0,
                # which is false: the traffic network didn't end, the
                # clock just cut it off. Standard fix (CleanRL / Gymnasium
                # guidance for TimeLimit truncation in PPO): fold the TRUE
                # next-observation's bootstrap value directly into this
                # step's reward before GAE ever sees it, using next_obs as
                # it actually was BEFORE env.reset() overwrites `obs`.
                with torch.no_grad():
                    x_next = torch.as_tensor(next_obs["node_features"], dtype=torch.float32, device=device)
                    _, true_next_value = net.forward(x_next)
                agent_rewards = agent_rewards + cfg.gamma * true_next_value.cpu().numpy()

            buffer.add(feats, actions_np, log_probs.cpu().numpy(), values.cpu().numpy(),
                       agent_rewards, float(episode_done), eligible_np)

            obs = next_obs
            if episode_done:
                last_completed_episode_reward = episode_reward
                last_completed_mean_wait = ep_wait_sum / max(ep_steps, 1)
                last_completed_mean_vehicle_wait = info["mean_vehicle_wait"]
                ep_wait_sum, ep_steps = 0.0, 0
                episode += 1
                obs, _ = env.reset(seed=training_env_seed(cfg.seed, episode))
                episode_reward = 0.0

        # bootstrap value for the state right after the last stored step
        with torch.no_grad():
            x = torch.as_tensor(obs["node_features"], dtype=torch.float32, device=device)
            _, last_values = net.forward(x)
        advantages, returns = buffer.compute_gae(last_values.cpu().numpy(), cfg.gamma, cfg.gae_lambda)

        b_obs, b_actions, b_log_probs, b_advantages, b_returns, b_eligible = buffer.get_flat(advantages, returns)
        # Standard PPO implementation detail (universal in reference code,
        # e.g. OpenAI Baselines), not explicitly tabulated in the paper:
        # normalize advantages per-update to stabilize the policy gradient
        # scale across updates.
        # statistics over ELIGIBLE rows only: ineligible rows have no policy gradient (action is forced),
        # so including them would only distort the mean/std the real samples are normalized by
        _adv_e = b_advantages[b_eligible]
        b_advantages = (b_advantages - _adv_e.mean()) / (_adv_e.std() + 1e-8)

        b_obs_t = torch.as_tensor(b_obs, device=device)
        b_actions_t = torch.as_tensor(b_actions, device=device)
        b_log_probs_t = torch.as_tensor(b_log_probs, device=device)
        b_advantages_t = torch.as_tensor(b_advantages, device=device)
        b_returns_t = torch.as_tensor(b_returns, device=device)
        b_eligible_t = torch.as_tensor(b_eligible, device=device)

        dataset_size = len(b_obs)
        last_policy_loss = last_value_loss = last_entropy = float("nan")
        for _epoch in range(cfg.num_epochs):
            idx = shuffle_rng.permutation(dataset_size)
            for start in range(0, dataset_size, cfg.minibatch_size):
                mb_idx = idx[start:start + cfg.minibatch_size]
                logits, values_pred = net(b_obs_t[mb_idx])
                logits = mask_switch_logits(logits, b_eligible_t[mb_idx])
                dist = torch.distributions.Categorical(logits=logits)
                new_log_probs = dist.log_prob(b_actions_t[mb_idx])
                entropy = dist.entropy().mean()

                ratio = torch.exp(new_log_probs - b_log_probs_t[mb_idx])
                mb_adv = b_advantages_t[mb_idx]
                surr1 = ratio * mb_adv
                surr2 = torch.clamp(ratio, 1 - cfg.clip_epsilon, 1 + cfg.clip_epsilon) * mb_adv
                policy_loss = -torch.min(surr1, surr2).mean()  # L^CLIP, Eq. 7 (negated for gradient descent)
                value_loss = (values_pred - b_returns_t[mb_idx]).pow(2).mean()  # L^VF, Eq. 9

                loss = policy_loss + cfg.value_coeff * value_loss - cfg.entropy_coeff * entropy

                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(net.parameters(), cfg.max_grad_norm)
                optimizer.step()

                last_policy_loss, last_value_loss, last_entropy = (
                    policy_loss.item(), value_loss.item(), entropy.item()
                )

        if update % cfg.log_every == 0:
            print(
                f"update {update:>5d} | env_step {env_step:>7d} | ep {episode:>4d} | "
                f"episode_reward {last_completed_episode_reward:8.1f} | wait {info['total_waiting_time']:8.1f} | "
                f"policy_loss {last_policy_loss:+.4f} | value_loss {last_value_loss:.4f} | entropy {last_entropy:.4f}"
            )
            row = [update, env_step, episode, last_completed_episode_reward, info["total_waiting_time"],
                   info["throughput"], last_policy_loss, last_value_loss, last_entropy,
                   last_completed_mean_wait, last_completed_mean_vehicle_wait]
            log_writer.writerow(row[:log_n_cols] if log_n_cols else row)
            log_file.flush()

        if update % cfg.checkpoint_every == 0:
            torch.save(net.state_dict(), os.path.join(out_dir, f"actor_critic_update{update}.pt"))

    final_ckpt_name = "actor_critic_final.pt" if end_update >= cfg.total_updates else "actor_critic_latest.pt"
    torch.save(net.state_dict(), os.path.join(out_dir, final_ckpt_name))
    with open(os.path.join(out_dir, "resume_state.json"), "w") as f:
        import json
        json.dump({"update": end_update, "episode": episode, "done_training": end_update >= cfg.total_updates}, f)
    log_file.close()
    env.close()
    print(f"Chunk complete: ran updates {start_update + 1}..{end_update} of {cfg.total_updates}. "
          f"Checkpoint: {os.path.join(out_dir, final_ckpt_name)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--net_file", default=DEFAULT_NET_FILE)
    parser.add_argument("--route_file", default=DEFAULT_ROUTE_FILE)
    parser.add_argument("--out", default=DEFAULT_OUT)
    parser.add_argument("--updates", type=int, default=None, help="override cfg.total_updates (grand total target)")
    parser.add_argument("--chunk_updates", type=int, default=None,
                         help="run only this many PPO updates in this invocation, then save and exit")
    parser.add_argument("--resume", default=None, help="path to a checkpoint (.pt) to resume weights from")
    parser.add_argument("--start_update", type=int, default=0)
    parser.add_argument("--start_episode", type=int, default=0)
    parser.add_argument("--seed", type=int, default=None,
                         help="override cfg.seed (default: whatever PPOConfig() sets, currently "
                              "42). Use this to train multiple seeds for the same budget, e.g. "
                              "--seed 1 --out runs/ppo_run_matched500_seed1 -- a single training "
                              "seed can't distinguish a real algorithmic difference from seed "
                              "variance, so report results across at least a few seeds rather "
                              "than one.")
    parser.add_argument("--gui", action="store_true")
    # parse_known_args (not parse_args) so the VS Code Play button, which
    # passes zero arguments, never errors out here -- matches dqn/train.py.
    args, _unknown = parser.parse_known_args()

    cfg = PPOConfig()
    if args.seed is not None:
        cfg.seed = args.seed
    if args.updates is not None:
        cfg.total_updates = args.updates

    train(
        cfg, args.net_file, args.route_file, args.out, use_gui=args.gui,
        resume_from=args.resume, start_update=args.start_update, start_episode=args.start_episode,
        chunk_updates=args.chunk_updates,
    )